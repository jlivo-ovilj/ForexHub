# ForexHub — Fix Log

**Any AI session working on this site: read this file first, before touching code.**

Owner: John · Repo: `github.com/jlivo-ovilj/ForexHub` · Last updated: 2026-08-17

---

## Rules for sessions

1. **Read this file before proposing anything.** If an issue below is marked
   `TRIED — FAILED`, do not try that approach again.
2. **Do not claim something is fixed unless the acceptance test passed.**
   The sandbox has restricted network access and cannot load the live site.
   If you could not run the test, say so plainly: *"code written, not verified live."*
3. **Update this file in the same commit as the fix.** Move the issue's status,
   record what you changed and where (function name + line), and record what you
   could not verify.
4. **One root cause beats five patches.** Several issues below share causes.
   Diagnose before editing.
5. **Never mark an issue closed.** Only John closes issues, after he has run the
   acceptance test himself.

---

## Architecture (why fixes keep breaking each other)

| Thing | Where | Note |
|---|---|---|
| Front end | `index.html` | **4,130 lines, 256KB — all HTML, CSS and JS in one file.** 221 functions. This is the main source of regressions: no change is isolated. |
| Data / AI proxy | `forexproxy-worker.js` → Cloudflare Worker `forexproxy` | Serves `/price`, `/calendar`, `/briefing`, `/health`, `/api` |
| Site hosting | Cloudflare Worker `forexhub` | **Not GitHub Pages.** Task lists have said Pages before — they were wrong. |
| Stray file | `forex-app (1).html` | Leftover, unused. Safe to delete. |

**Open structural recommendation:** split `index.html` into `index.html` +
`styles.css` + `app.js` (or several JS modules). Until this happens, expect
unrelated features to break on every edit. Not yet done — needs John's go-ahead.

---

## Diagnostics John can run without a session

**Upstream health check** — paste into any browser:

```
https://forexproxy.jlivo10.workers.dev/health
```

Returns whether Yahoo (prices) and the Forex Factory feed (calendar) are actually
responding, plus how long they took. Use this **first** whenever data looks wrong:

- Upstreams alive + site shows no data → fault is in the **front end**
- Upstreams dead → fault is **upstream or the worker**

This single check tells you which half of the site to blame. Costs nothing.

---

## Issue register

Status values: `OPEN` · `FIX SHIPPED — UNVERIFIED` · `VERIFIED BY JOHN` · `TRIED — FAILED`

---

### D1 — Live prices fail / "Failed to fetch" / data not refreshing
**Seen in:** R1, R2, R3, R4 — the longest-running issue.
**Affects:** ticker, heat map, daily scanner, briefing figures, calculator.

**Root cause identified (17.8.26):** every request went straight to Yahoo with no
edge cache and no retry. Ticker + heat map + calculator + briefing all firing at
once tripped Yahoo's rate limiter, and the whole site showed "No live data returned."

**Fix shipped in V7:** edge caching (`cacheTtl`), `query1 → query2` mirror fallback,
one backoff retry, and failed pairs now reported in a `missing` array instead of
being silently dropped. See `yChart()` in `forexproxy-worker.js`.

**Status:** `FIX SHIPPED — UNVERIFIED`

**Acceptance test:**
1. Hard-refresh the live site (Ctrl+Shift+R).
2. Every pair in the ticker and heat map shows a price — no blanks, no dashes.
3. Leave the page open 10 minutes, refresh again — prices have moved.
4. Open several sections at once (heat map + scanner + briefing). Still no failures.
5. Check `/health` — Yahoo reports alive.

---

### D2 — Economic calendar not populating / passed events not clearing
**Seen in:** R1–R4.

**Fix shipped in V7:** worker `/calendar` endpoint now proxies the real Forex Factory
feed (`nfs.faireconomy.media`) with a 15-minute edge cache. Front end at
`CAL_URL` (line ~2539); day filtering in `parseCalDay()` / `filterCalEvents()`
(lines ~2084–2092), Brisbane-time keyed via `aestKey()`.

**Status:** `FIX SHIPPED — UNVERIFIED`

**Acceptance test:**
1. Calendar shows events for today and the rest of this week.
2. An event whose time has passed is either removed or visibly marked as passed.
3. Day boundaries are correct in Brisbane time — nothing from yesterday shows as today.
4. Filters (importance / currency / days) work and survive a page refresh.

---

### D3 — AI narration and cite blocks leaking into the news display
**Seen in:** R2, R3, R4.
**Symptom:** conversational filler and `<cite index="...">` tags appear in news items.

**Handled at:** `stripNarration()` (~line 3908) and the render-time strip (~3993–3996),
which remove `<cite>` tags, `[1]` markers, and `(Source: ...)` text.

**Root cause:** the model was asked for prose, then ~40 lines of regex tried to
strip its narration and `<cite>` markup afterwards. Model phrasing varies, so a
regex block-list always leaks eventually. Patching the regexes was never going to
end — that approach is a dead end and should not be attempted again.

**Fix shipped (17.8.26, structured-JSON rewrite):**
- The news prompt now demands a **JSON array** — no prose to strip.
- `parseNewsJSON()` extracts and validates it; tolerates code fences and stray
  narration around the array, discards malformed entries, normalises `ccy`,
  rejects invalid `impact` values.
- `renderNewsJSON()` renders from fields, HTML-escaping every value via a new
  `esc()` helper. A `<cite>` tag can no longer render as markup even if one arrives.
- **The old prose path is untouched and still runs as a fallback** if JSON parsing
  fails, so behaviour can only improve, not regress.
- Cache key bumped to `brief-news-j:` so yesterday's cached prose isn't fed to the
  new parser; `forceBrief()` clears both old and new keys.

**Tested:** 21 automated tests pass — clean JSON, code fences, leading/trailing
narration, empty array, malformed JSON, non-array JSON, junk entries, bad `impact`,
lowercase `ccy`, all render fields, plus three leakage tests (cite tags neutralised,
narration cannot survive, HTML injection escaped). JS syntax verified with `node --check`.

**Not tested:** the live round-trip — the sandbox cannot reach the site, and no real
model response was exercised. Verify with the test below.

**Status:** `FIX SHIPPED — UNVERIFIED LIVE`

**Acceptance test:**
1. Open the briefing / news panel.
2. No `<cite>`, no `index=`, no bracketed numbers, no "Here's a summary", no
   "Let me know if...", no "Source:" lines.
3. Force a refresh via `forceBrief()` (~line 4096) and re-check — 3 times running.

---

### D4 — Gap indicator misreads gaps
**Handled at:** `gapCalc()` (~4051), `renderGapTable()` (~4061); worker-side
`gapPips` in the `/briefing` endpoint, anchored to the 5pm-New-York rollover.

**V7 note:** rollover anchoring was reworked (17:00 NY ≈ 07:00 Brisbane).
Tradable/all filter added — `gapFilterMode()` / `setGapFilter()` (~4059–4060).

**Status:** `FIX SHIPPED — UNVERIFIED`

**Acceptance test:**
1. On a Monday, the weekend gap shows and matches what your broker platform shows.
2. Mid-week, gaps are near-zero — not showing a full day's move as a "gap".
3. The tradable/all toggle changes the row count and the setting survives a refresh.

---

### D5 — Conflicting scanner signals
**Seen in:** R2, R3, R4. **Symptom:** two parts of the site disagree on the same pair.
**Handled at:** `setScanMode()` (~3274).

**ROOT CAUSE FOUND (17.8.26 audit) — this was never a bug.**

Nothing computes change locally; every number comes from the worker. But the site
reads from **two endpoints with different time periods**, and neither is labelled:

| Display | Source | Period actually measured |
|---|---|---|
| Ticker, heat map, scanner, movers | `/price` → `td` / `chg` / `dp` | **Today so far**, since the 5pm-NY rollover (~7am AEST) |
| Briefing headline rows | `/briefing` → `prevDayMovePips` | **Yesterday's completed session** |

So if a pair rose yesterday and is falling today, the scanner and the briefing
correctly disagree — they are reporting different days. No amount of patching
either display will ever reconcile them.

**Second, subtler problem (line ~3939 and ~3967):** the briefing falls back
`prevDayMovePips ?? movePips`, and the "biggest mover" alert switches between
`sessionMovePips` and `displayPips` depending on what data arrived. So the period
being shown can **change silently between page loads**. That is almost certainly
what makes the inconsistency feel random rather than reproducible.

**Recommended fix (NOT yet implemented — needs John's decision):**
This is a labelling and consistency problem, not a maths problem. Options:
1. **Label every figure with its period** ("since 7am AEST" vs "yesterday's session")
   — smallest change, makes the disagreement legible instead of wrong-looking.
2. **Make the briefing show today-so-far** to match everything else, with
   yesterday's move as a clearly-marked secondary column.
3. **Make the silent fallbacks explicit** — if `sessionMovePips` is missing, say so
   rather than quietly switching to a different period.

Do 3 regardless. John picks between 1 and 2.

**Acceptance test (once implemented):** pick one pair. Every figure on the site
either reads identically, or is explicitly labelled with the period it covers.
Reload five times — the period shown never changes on its own.

---

### D6 — Currency-pair colour coding inconsistent
**Seen in:** R1–R4. Partly addressed in V7 (Planner pair list: colour + A–Z ordering).

**Status:** `FIX SHIPPED — UNVERIFIED` (Planner only; other views unconfirmed)

**Acceptance test:** the same currency uses the same colour in the planner,
watchlist, news strip and heat map. No pair is uncoloured.

---

### D7 — Readability: bolder text, yellow-box contrast
**Seen in:** R1–R4. Cosmetic but repeatedly raised and repeatedly not resolved.

**Status:** `OPEN`

**Acceptance test:** John can read every panel comfortably on his usual device,
including the yellow-background boxes, without leaning in.

---

### D8 — Report / email formatting
**Status:** `OPEN` — needs a spec. Currently unfixable because "correct formatting"
has never been defined. **Next action: John describes or sketches the desired output
once, and it gets pasted into this section.** Until then, sessions should not attempt it.

---

### D9 — Export / save / timestamp features
**Handled at:** `exportJournal()` (~2811), `saveJournal()` (~2767),
`downloadCanvas()` (~2068), `saveLastQuotes()` (~1581).

**Status:** `OPEN` — specific failure never pinned down.
**Next action:** John names which export, what he did, and what happened.
One concrete report beats another speculative fix.

---

### D10 — Market Sessions timeline correlation
**Fix shipped in V7:** timeline anchored to the 7am Brisbane rollover.

**Status:** `FIX SHIPPED — UNVERIFIED`

**Acceptance test:** session bars (Sydney / Tokyo / London / New York) line up with
the current Brisbane time, and the "now" marker sits in the right place.

---

## Version history

| Version | Date | Contents |
|---|---|---|
| V7 | 2026-08-17 | Sessions timeline anchored to 7am rollover; gap tradable/all filter; one canonical 28-pair watchlist with NZD crosses; real Forex Factory calendar feed; price-feed caching + retry + fallback |
| R1–R4 | earlier | Four rounds of revisions; recurring issues catalogued above |

---

## Session log

Add a row per session. Be honest about what was not verified.

| Date | What was changed | Verified live? | Notes |
|---|---|---|---|
| 2026-08-17 | V7 — five fixes (see above) | **No** — sandbox could not reach the live site; Chrome extension would not connect | Deploy did complete: repo commit `236e239` + both Cloudflare workers updated |
| 2026-08-17 | This file created | n/a | Audit found the single-file architecture as the structural cause of repeat regressions |
| 2026-08-17 | D3 rewritten to structured JSON (`parseNewsJSON`, `renderNewsJSON`, `esc`); prose path kept as fallback | **Unit-tested (21/21), not verified live** | Regex-stripping approach marked dead end — do not revisit |
| 2026-08-17 | D5 root-caused — no code changed | n/a | Two endpoints measuring different periods; needs John's decision between labelling and realigning |
